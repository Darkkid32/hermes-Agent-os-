# Hermes Agent OS Runtime

Local-first Agent OS dashboard and backend runtime with the existing Hermes Agent Hub UI.

## What is included

- Real `@elizaos/core` runtime foundation loaded by the backend and reported through `/api/os/foundation`.
- Sanitized Agent OS module registry for Claude Code, OpenClaw, OpenClaude, Hermes Agent, Gemini, Codex, OpenCode, Free Claude Code routing, Firecrawl Agent Builder, Goals, SEO, Video, Notebook, Kanban, and Usage Credits.
- Vendored upstream Firecrawl Open Agent Builder from `firecrawl/open-agent-builder` with an isolated Hermes purple theme override.
- Local workflow API seed reset to a blank upstream-style starter; no Hermes lead-intake demo workflow is shipped by default.
- Local state under `~/.hermes-agent-os/` for config, workflows, runs, logs, memory, and exports.
- Hidden clean export flow for preparing a distributable package without local data, profiles, logs, run history, or secrets.

## Local run

```bash
npm install
npm run dev
```

Frontend: `http://localhost:5173`

Backend: `http://localhost:4173/api/health`

## Real Agent Builder

The dashboard embeds the real vendored Open Agent Builder through `/agent-builder-source/?view=builder`.

```bash
npm run builder:install
npm run builder:start
```

The upstream builder requires Convex and Clerk before it can render:

- `NEXT_PUBLIC_CONVEX_URL`
- `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`
- `CLERK_SECRET_KEY`
- `CLERK_JWT_ISSUER_DOMAIN`

Configure these through the Firecrawl Agent Builder card or the local connection API. Add `FIRECRAWL_API_KEY` and LLM keys when you want execution, not just design.

## Production run

```bash
npm run build
npm start
```

The Express server serves both `/api/*` and the built React app from `dist`.

## Environment

Copy `.env.example` to `.env` when needed.

Important variables:

- `HERMES_AGENT_OS_HOME`: defaults to `~/.hermes-agent-os`
- `HERMES_AGENT_OS_ENABLE_EXEC`: keep `0` for dry-run dispatch, set `1` only on a trusted local machine
- `HERMES_AGENT_OS_ENABLE_INSTALL`: keep `0` to show install commands only; set `1` only on a trusted local machine
- `HERMES_AGENT_OS_ADMIN_TOKEN`: required for the admin export endpoint
- `HERMES_BUILDER_PORT`: defaults to `3100`
- `FIRECRAWL_API_KEY`: enables Firecrawl web/data workflow execution in the builder
- `NEXT_PUBLIC_CONVEX_URL`, `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY`, `CLERK_JWT_ISSUER_DOMAIN`: required by upstream Open Agent Builder
- Provider keys such as `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, and `MINIMAX_API_KEY` stay local

## API

- `GET /api/os/status`
- `GET /api/os/foundation`
- `GET /api/os/audit`
- `GET /api/modules`
- `GET /api/modules/:id`
- `POST /api/modules/:id/install`
- `POST /api/modules/:id/test`
- `POST /api/modules/:id/run`
- `GET /api/modules/:id/logs`
- `GET /api/connections`
- `GET /api/installers`
- `POST /api/connections/:id/configure`
- `POST /api/connections/:id/test`
- `GET /api/builder/status`
- `GET /api/workflows`
- `POST /api/workflows`
- `GET /api/workflows/:id`
- `PUT /api/workflows/:id`
- `POST /api/workflows/:id/run`
- `GET /api/workflows/:id/runs/:runId`
- `POST /api/admin/export/prepare`

Compatibility aliases remain for the previous dashboard build:

- `GET /api/integrations`
- `POST /api/integrations/:id/test`
- `POST /api/agents/:id/message`

## Clean export

```bash
npm run prepare-export
```

The export command writes a clean package under the local Agent OS export directory and fails if the audit detects secrets, local home paths, runtime data, private Hermes profile paths, or local profile names.
