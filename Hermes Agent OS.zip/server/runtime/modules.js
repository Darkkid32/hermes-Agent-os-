import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { getConfiguredValue, getStoredConnectionConfig } from "./connections.js";
import { getElizaStatus } from "./eliza.js";
import { getInstallRecipe } from "./installers.js";
import { appendModuleLog, readModuleLogs } from "./module-logs.js";
import { commandVersion, publicEnvConfigured, runCommand, sanitizeObject, which } from "./safety.js";
import { getLocalSelfModuleStatus, isLocalSelfModule } from "./self-modules.js";
import { ensureRuntimeStore, expandHome, publicRuntimePath, runtimePaths, RUNTIME_VERSION } from "./store.js";

const CLI_MODULES = [
  {
    id: "claude",
    label: "Claude Code",
    command: "claude",
    category: "agent",
    envKeys: ["ANTHROPIC_API_KEY", "CLAUDE_CODE_PATH"],
    pathKeys: ["CLAUDE_CODE_PATH", "CLAUDE_CLI_PATH"],
    capabilities: ["chat", "code", "tools", "mcp"],
    installHint: "Install Claude Code from Anthropic, or configure CLAUDE_CODE_PATH.",
    docsUrl: "https://docs.anthropic.com/claude-code"
  },
  {
    id: "openclaw",
    label: "OpenClaw",
    command: "openclaw",
    category: "agent",
    envKeys: ["OPENCLAW_CLI_PATH", "OPENCLAW_HOME"],
    pathKeys: ["OPENCLAW_CLI_PATH"],
    capabilities: ["automation", "browser", "tools"],
    installHint: "Install OpenClaw locally, or configure OPENCLAW_CLI_PATH and OPENCLAW_HOME.",
    docsUrl: "https://github.com/search?q=openclaw&type=repositories"
  },
  {
    id: "openclaude",
    label: "OpenClaude",
    command: "openclaude",
    category: "agent",
    envKeys: ["OPENCLAUDE_CLI_PATH", "OPENCLAUDE_API_KEY", "OPENROUTER_API_KEY", "OLLAMA_HOST"],
    pathKeys: ["OPENCLAUDE_CLI_PATH"],
    capabilities: ["chat", "routing", "local-models"],
    installHint: "No trusted OpenClaude package is bundled. Configure OPENCLAUDE_CLI_PATH for a real local OpenClaude-compatible CLI, or route Claude-style work through OpenRouter/Ollama.",
    docsUrl: "https://www.npmjs.com/package/openclaude"
  },
  {
    id: "gemini",
    label: "Gemini",
    command: "gemini",
    category: "agent",
    envKeys: ["GEMINI_API_KEY", "GEMINI_CLI_PATH"],
    pathKeys: ["GEMINI_CLI_PATH"],
    capabilities: ["chat", "code", "vision"],
    installHint: "Install Gemini CLI, or configure GEMINI_CLI_PATH and GEMINI_API_KEY.",
    docsUrl: "https://github.com/google-gemini/gemini-cli"
  },
  {
    id: "codex",
    label: "Codex",
    command: "codex",
    category: "agent",
    envKeys: ["OPENAI_API_KEY", "CODEX_CLI_PATH"],
    pathKeys: ["CODEX_CLI_PATH"],
    capabilities: ["code", "workspace", "review"],
    installHint: "Install Codex CLI, or configure CODEX_CLI_PATH and OPENAI_API_KEY.",
    docsUrl: "https://developers.openai.com/codex"
  },
  {
    id: "opencode",
    label: "OpenCode",
    command: "opencode",
    category: "agent",
    envKeys: ["OPENCODE_CLI_PATH"],
    pathKeys: ["OPENCODE_CLI_PATH"],
    capabilities: ["code", "workspace"],
    installHint: "Install OpenCode locally, or configure OPENCODE_CLI_PATH.",
    docsUrl: "https://opencode.ai"
  }
];

const INTERNAL_MODULES = [
  {
    id: "goals",
    label: "Goals",
    category: "self",
    capabilities: ["goals", "plans", "progress"],
    publicSummary: "Local goal loops, run state, and progress tracking."
  },
  {
    id: "seo",
    label: "SEO",
    category: "self",
    capabilities: ["keyword-research", "content-briefs", "site-audits"],
    publicSummary: "SEO workflow module ready for user-owned projects and APIs."
  },
  {
    id: "video",
    label: "Video",
    category: "self",
    capabilities: ["captioning", "scripts", "render-plans"],
    publicSummary: "Video workflow module for captions, scripts, and render handoff."
  },
  {
    id: "notebook",
    label: "Notebook",
    category: "self",
    capabilities: ["notes", "memory", "run-journal"],
    publicSummary: "Local notebook and run journal backed by the Agent OS store."
  },
  {
    id: "kanban",
    label: "Kanban",
    category: "self",
    capabilities: ["tasks", "queues", "handoffs"],
    publicSummary: "Local Kanban queues for agent work and human approvals."
  },
  {
    id: "usage-credits",
    label: "Usage Credits",
    category: "self",
    capabilities: ["usage", "quotas", "spend-estimates"],
    publicSummary: "Tracks local usage budgets and provider credit estimates."
  }
];

const PROVIDER_MODULES = [
  {
    id: "provider-anthropic",
    label: "Anthropic",
    envKeys: ["ANTHROPIC_API_KEY"],
    configuredFrom: ["provider-anthropic", "claude", "firecrawl-builder"],
    capabilities: ["llm", "claude", "agent-routing"],
    publicSummary: "Connect a user-owned Anthropic key for Claude models and Claude Code workflows.",
    docsUrl: "https://docs.anthropic.com"
  },
  {
    id: "provider-openai",
    label: "OpenAI",
    envKeys: ["OPENAI_API_KEY"],
    configuredFrom: ["provider-openai", "codex", "firecrawl-builder"],
    capabilities: ["llm", "codex", "agent-routing"],
    publicSummary: "Connect a user-owned OpenAI key for Codex and OpenAI model routing.",
    docsUrl: "https://platform.openai.com/docs"
  },
  {
    id: "provider-gemini",
    label: "Gemini API",
    envKeys: ["GEMINI_API_KEY"],
    configuredFrom: ["provider-gemini", "gemini"],
    capabilities: ["llm", "vision", "agent-routing"],
    publicSummary: "Connect a user-owned Gemini API key for Gemini model routing.",
    docsUrl: "https://github.com/google-gemini/gemini-cli"
  },
  {
    id: "provider-openrouter",
    label: "OpenRouter",
    envKeys: ["OPENROUTER_API_KEY"],
    configuredFrom: ["provider-openrouter", "free-claude-code", "openclaude"],
    capabilities: ["llm", "routing", "open-models"],
    publicSummary: "Connect a user-owned OpenRouter key for Claude-style/open-provider routing.",
    docsUrl: "https://openrouter.ai/docs"
  },
  {
    id: "provider-ollama",
    label: "Ollama",
    envKeys: ["OLLAMA_HOST"],
    configuredFrom: ["provider-ollama", "free-claude-code", "openclaude"],
    capabilities: ["local-models", "routing"],
    publicSummary: "Connect a local Ollama host for local model routing.",
    docsUrl: "https://ollama.com"
  },
  {
    id: "provider-minimax",
    label: "MiniMax",
    envKeys: ["MINIMAX_API_KEY"],
    configuredFrom: ["provider-minimax", "minimax", "free-claude-code"],
    capabilities: ["llm", "routing"],
    publicSummary: "Connect a user-owned MiniMax API key.",
    docsUrl: "https://www.minimax.io"
  },
  {
    id: "provider-firecrawl",
    label: "Firecrawl",
    envKeys: ["FIRECRAWL_API_KEY"],
    configuredFrom: ["provider-firecrawl", "firecrawl-builder"],
    capabilities: ["web-data", "scrape", "mcp"],
    publicSummary: "Connect Firecrawl for web/data execution in Open Agent Builder.",
    docsUrl: "https://docs.firecrawl.dev"
  },
  {
    id: "provider-convex",
    label: "Convex",
    envKeys: ["NEXT_PUBLIC_CONVEX_URL"],
    configuredFrom: ["provider-convex", "firecrawl-builder"],
    capabilities: ["database", "workflow-storage"],
    publicSummary: "Connect Convex so the upstream Open Agent Builder can persist workflows.",
    docsUrl: "https://docs.convex.dev"
  },
  {
    id: "provider-clerk",
    label: "Clerk",
    envKeys: ["NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY", "CLERK_SECRET_KEY", "CLERK_JWT_ISSUER_DOMAIN"],
    configuredFrom: ["provider-clerk", "firecrawl-builder"],
    capabilities: ["auth", "builder-login"],
    publicSummary: "Connect Clerk authentication required by the upstream Open Agent Builder.",
    docsUrl: "https://clerk.com/docs"
  }
];

function now() {
  return new Date().toISOString();
}

function standardModule(input) {
  const configured = Boolean(input.configured);
  const status = input.status || (configured ? "connected" : "ready_to_configure");
  return {
    id: input.id,
    label: input.label,
    category: input.category,
    type: input.type || input.category,
    status,
    capabilities: input.capabilities || [],
    configured,
    missing: input.missing || [],
    lastChecked: now(),
    actions: input.actions || ["configure", "test", "run", "logs"],
    publicSummary: input.publicSummary || input.connection || "",
    connection: input.connection || input.publicSummary || "",
    version: input.version || null,
    profile: input.profile || null,
    profileCount: input.profileCount,
    onlineProfiles: input.onlineProfiles,
    stats: input.stats || {},
    source: input.source || "hermes-agent-os-runtime",
    configKeys: input.configKeys || [],
    installHint: input.installHint || "",
    installCommand: input.installCommand || "",
    installMode: input.installMode || "",
    docsUrl: input.docsUrl || ""
  };
}

function recipeFields(id) {
  const recipe = getInstallRecipe(id);
  return recipe
    ? {
        installCommand: recipe.command || "",
        installMode: recipe.manager,
        docsUrl: recipe.docsUrl || ""
      }
    : {};
}

function cliDefinition(id) {
  return CLI_MODULES.find((definition) => definition.id === id) || null;
}

async function resolveCliCommand(definition, stored) {
  const configuredPath = (definition.pathKeys || [`${definition.id.toUpperCase().replaceAll("-", "_")}_CLI_PATH`])
    .map((key) => getConfiguredValue(stored, definition.id, key))
    .find(Boolean);
  if (configuredPath) {
    const expanded = expandHome(configuredPath);
    try {
      await fs.access(expanded);
      return { commandPath: expanded, configuredPath: true, configuredPathMissing: false };
    } catch {
      return { commandPath: "", configuredPath: true, configuredPathMissing: true };
    }
  }
  return { commandPath: await which(definition.command), configuredPath: false, configuredPathMissing: false };
}

async function cliModule(definition, stored) {
  const resolved = await resolveCliCommand(definition, stored);
  const commandPath = resolved.commandPath;
  const version = await commandVersion(commandPath);
  const hasProviderConfig = definition.envKeys.some((key) => Boolean(getConfiguredValue(stored, definition.id, key)));
  const connected = Boolean(commandPath);
  return standardModule({
    id: definition.id,
    label: definition.label,
    category: definition.category,
    type: "cli",
    status: connected ? "connected" : "missing_dependency",
    configured: connected || hasProviderConfig,
    missing: connected ? [] : [resolved.configuredPathMissing ? "configured CLI path not found" : definition.command],
    capabilities: definition.capabilities,
    configKeys: definition.envKeys,
    installHint: definition.installHint,
    docsUrl: definition.docsUrl,
    version,
    publicSummary: connected
      ? `${definition.label} CLI is installed and callable by the local runtime.`
      : `${definition.label} is ready; install ${definition.command} or configure a local path.`,
    actions: connected ? ["test", "run", "logs"] : ["install", "configure", "docs"],
    ...recipeFields(definition.id)
  });
}

async function hermesModule() {
  const hermesHome = expandHome(process.env.HERMES_HOME) || path.join(os.homedir(), ".hermes");
  let entries = [];
  try {
    entries = await fs.readdir(path.join(hermesHome, "profiles"), { withFileTypes: true });
  } catch {
    entries = [];
  }
  const profileCount = entries.filter((entry) => entry.isDirectory()).length;
  return standardModule({
    id: "hermes",
    label: "Hermes Agent",
    category: "agent",
    type: "local_runtime",
    status: profileCount ? "connected" : "ready_to_configure",
    configured: profileCount > 0,
    missing: profileCount ? [] : ["HERMES_HOME"],
    capabilities: ["memory", "skills", "gateway", "channels"],
    configKeys: ["HERMES_HOME"],
    installHint: "Install or point Hermes Agent at a local HERMES_HOME profile directory.",
    profileCount,
    publicSummary: profileCount
      ? "Hermes runtime structure detected locally. Profile details remain private."
      : "Set HERMES_HOME or install Hermes Agent to connect local runtime state.",
    actions: profileCount ? ["test", "run", "logs"] : ["install", "configure", "docs"],
    ...recipeFields("hermes")
  });
}

async function gatewayModule(hermes) {
  const connected = hermes.status === "connected";
  return standardModule({
    id: "gateway",
    label: "Hermes Gateway",
    category: "runtime",
    type: "gateway",
    status: connected ? "connected" : "ready_to_configure",
    configured: connected,
    missing: connected ? [] : ["Hermes profiles"],
    capabilities: ["telegram", "browser", "webhooks", "channels"],
    publicSummary: connected
      ? "Gateway can expose configured local channels without returning private channel data."
      : "Gateway is ready; connect Hermes profiles and channels locally."
  });
}

async function elizaRuntimeModule() {
  const status = await getElizaStatus();
  return standardModule({
    id: "elizaos-runtime",
    label: "elizaOS Runtime",
    category: "runtime",
    type: "agent_os_core",
    status: status.ok ? "connected" : "error",
    configured: status.ok,
    missing: status.missingExports,
    capabilities: ["agents", "plugins", "memory", "model-routing", "services"],
    version: status.version,
    publicSummary: status.ok
      ? `Real ${status.packageName} ${status.version} is installed and loadable.`
      : "elizaOS core is not loadable; install @elizaos/core.",
    actions: ["test", "logs"],
    source: status.source,
    stats: {
      runtimeClass: status.runtimeClass,
      exports: status.exports
    },
    installHint: "Installed through npm dependency @elizaos/core. This is the Agent OS runtime foundation Hermes wraps."
  });
}

async function minimaxModule(stored) {
  const configured = ["minimax", "provider-minimax", "free-claude-code"].some((id) =>
    Boolean(getConfiguredValue(stored, id, "MINIMAX_API_KEY"))
  );
  return standardModule({
    id: "minimax",
    label: "MiniMax M3",
    category: "provider",
    type: "provider",
    status: configured ? "connected" : "ready_to_configure",
    configured,
    missing: configured ? [] : ["MINIMAX_API_KEY"],
    capabilities: ["chat", "routing"],
    configKeys: ["MINIMAX_API_KEY"],
    installHint: "Add a user-owned MiniMax API key to enable MiniMax routing.",
    publicSummary: configured
      ? "MiniMax provider is configured locally."
      : "Add MINIMAX_API_KEY to enable MiniMax routing."
  });
}

function providerConfigured(stored, definition) {
  return definition.envKeys.every((key) =>
    publicEnvConfigured(key) ||
    definition.configuredFrom.some((id) => Boolean(stored?.[id]?.[key]))
  );
}

function providerModule(definition, stored) {
  const configured = providerConfigured(stored, definition);
  const missing = definition.envKeys.filter((key) =>
    !publicEnvConfigured(key) &&
    !definition.configuredFrom.some((id) => Boolean(stored?.[id]?.[key]))
  );
  return standardModule({
    id: definition.id,
    label: definition.label,
    category: "provider",
    type: "provider",
    status: configured ? "connected" : "ready_to_configure",
    configured,
    missing,
    capabilities: definition.capabilities,
    configKeys: definition.envKeys,
    publicSummary: configured
      ? `${definition.label} provider is configured locally.`
      : definition.publicSummary,
    actions: ["configure", "test", "logs"],
    docsUrl: definition.docsUrl,
    installHint: "No install required in Hermes. Add your own provider key or local endpoint."
  });
}

async function freeClaudeModule(stored) {
  const configured = ["OPENROUTER_API_KEY", "OLLAMA_HOST", "MINIMAX_API_KEY"].some((key) =>
    Boolean(getConfiguredValue(stored, "free-claude-code", key))
  );
  return standardModule({
    id: "free-claude-code",
    label: "Free Claude Code",
    category: "agent",
    type: "routing",
    status: configured ? "connected" : "ready_to_configure",
    configured,
    missing: configured ? [] : ["OPENROUTER_API_KEY or OLLAMA_HOST or MINIMAX_API_KEY"],
    capabilities: ["routing", "code", "local-models"],
    configKeys: ["OPENROUTER_API_KEY", "OLLAMA_HOST", "MINIMAX_API_KEY"],
    installHint: "Connect a user-owned OpenRouter, Ollama, or MiniMax provider. This does not include Anthropic access.",
    publicSummary: configured
      ? "Claude-style workflows route through user-owned local/open providers."
      : "Configure a user-owned provider; this does not provide free Anthropic access."
  });
}

async function firecrawlBuilderModule(stored) {
  const configuredFrom = ["firecrawl-builder", "provider-convex", "provider-clerk", "provider-firecrawl"];
  const requiredKeys = [
    "NEXT_PUBLIC_CONVEX_URL",
    "NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY",
    "CLERK_SECRET_KEY",
    "CLERK_JWT_ISSUER_DOMAIN",
    "FIRECRAWL_API_KEY"
  ];
  const missing = requiredKeys.filter((key) =>
    !publicEnvConfigured(key) &&
    !configuredFrom.some((id) => Boolean(stored?.[id]?.[key]))
  );
  const configured = missing.length === 0;
  return standardModule({
    id: "firecrawl-builder",
    label: "Firecrawl Agent Builder",
    category: "builder",
    type: "workflow_builder",
    status: configured ? "connected" : "ready_to_configure",
    configured,
    missing,
    capabilities: ["visual-workflows", "agent-nodes", "mcp-tools", "human-approval", "firecrawl"],
    configKeys: ["NEXT_PUBLIC_CONVEX_URL", "NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY", "CLERK_SECRET_KEY", "CLERK_JWT_ISSUER_DOMAIN", "FIRECRAWL_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GROQ_API_KEY", "ARCADE_API_KEY"],
    installHint: "Run npm run builder:install, configure Convex/Clerk keys, then npm run builder:start. Add Firecrawl and LLM keys for execution.",
    publicSummary: configured
      ? "Builder auth, storage, and Firecrawl execution are configured."
      : "Design workflows after the upstream builder is configured; add Convex, Clerk, and Firecrawl keys before claiming builder execution."
  });
}

async function internalModule(definition) {
  if (isLocalSelfModule(definition.id)) {
    const local = await getLocalSelfModuleStatus(definition.id);
    return standardModule({
      ...definition,
      type: "local_app",
      status: "connected",
      configured: true,
      missing: [],
      actions: ["open", "create", "run", "logs"],
      stats: local.summary,
      publicSummary: `${definition.publicSummary} ${local.itemCount} local item${local.itemCount === 1 ? "" : "s"} stored.`,
      installHint: "No external install required. This module stores user-owned data in the local Hermes Agent OS store."
    });
  }

  return standardModule({
    ...definition,
    type: "local_app",
    status: "ready_to_configure",
    configured: false,
    missing: ["module implementation"],
    actions: ["configure", "docs", "logs"],
    installHint: `${definition.label} is registered in the Agent OS module catalog. Implementation/configuration is still required before it can run real work.`
  });
}

export async function getModules() {
  await ensureRuntimeStore();
  const stored = await getStoredConnectionConfig();
  const cliModules = await Promise.all(CLI_MODULES.map((definition) => cliModule(definition, stored)));
  const hermes = await hermesModule();
  const gateway = await gatewayModule(hermes);
  const eliza = await elizaRuntimeModule();
  const minimax = await minimaxModule(stored);
  const freeClaude = await freeClaudeModule(stored);
  const firecrawlBuilder = await firecrawlBuilderModule(stored);
  const internalModules = await Promise.all(INTERNAL_MODULES.map(internalModule));
  const providerModules = PROVIDER_MODULES.map((definition) => providerModule(definition, stored));
  return [
    cliModules.find((module) => module.id === "claude"),
    cliModules.find((module) => module.id === "openclaw"),
    cliModules.find((module) => module.id === "openclaude"),
    hermes,
    cliModules.find((module) => module.id === "gemini"),
    cliModules.find((module) => module.id === "codex"),
    cliModules.find((module) => module.id === "opencode"),
    freeClaude,
    minimax,
    gateway,
    eliza,
    firecrawlBuilder,
    ...providerModules,
    ...internalModules
  ].filter(Boolean);
}

export async function getModule(id) {
  return (await getModules()).find((module) => module.id === id) || null;
}

export async function getOsStatus() {
  const modules = await getModules();
  const eliza = await getElizaStatus();
  const paths = runtimePaths();
  return {
    ok: true,
    service: "hermes-agent-os-runtime",
    version: RUNTIME_VERSION,
    mode: process.env.NODE_ENV || "development",
    runtimeFoundation: eliza.ok
      ? `elizaOS core ${eliza.version} loaded`
      : "elizaOS core not loaded",
    builderFoundation: "firecrawl-open-agent-builder-compatible workflow model",
    generatedAt: now(),
    host: os.hostname(),
    store: {
      root: publicRuntimePath(""),
      config: publicRuntimePath("config"),
      workflows: publicRuntimePath("workflows"),
      runs: publicRuntimePath("runs"),
      logs: publicRuntimePath("logs"),
      memory: publicRuntimePath("memory"),
      exports: publicRuntimePath("exports")
    },
    publicUrl: process.env.HERMES_AGENT_HUB_PUBLIC_URL || null,
    githubRepo: process.env.HERMES_AGENT_HUB_GITHUB_REPO || null,
    moduleCount: modules.length,
    connectedCount: modules.filter((module) => module.status === "connected").length,
    pathsReady: sanitizeObject(paths),
    elizaOS: eliza
  };
}

export async function getOsAudit() {
  const modules = await getModules();
  const items = modules.map((module) => {
    const connected = module.status === "connected";
    const severity = connected ? "ok" : module.status === "missing_dependency" || module.status === "error" ? "action_required" : "setup";
    const fix = connected
      ? "No action required."
      : module.installCommand
        ? `Install or configure ${module.label}. Suggested command: ${module.installCommand || "manual install"}.`
        : module.missing?.length
          ? `Configure ${module.missing.join(", ")}.`
          : module.configKeys?.length
            ? `Configure ${module.configKeys.join(", ")}.`
          : module.installHint || "Open this module and complete setup.";
    return {
      id: module.id,
      label: module.label,
      category: module.category,
      type: module.type,
      status: module.status,
      configured: module.configured,
      missing: module.missing,
      severity,
      fix,
      docsUrl: module.docsUrl || "",
      actions: module.actions
    };
  });
  return {
    generatedAt: now(),
    summary: {
      total: items.length,
      ok: items.filter((item) => item.severity === "ok").length,
      setup: items.filter((item) => item.severity === "setup").length,
      actionRequired: items.filter((item) => item.severity === "action_required").length
    },
    items
  };
}

export async function testModule(id) {
  const module = await getModule(id);
  if (!module) {
    return { ok: false, id, message: `No module registered for ${id}.`, details: null };
  }
  await appendModuleLog(id, {
    level: module.status === "connected" ? "info" : "warn",
    message: "Module health checked",
    details: {
      status: module.status,
      configured: module.configured,
      missing: module.missing
    }
  });
  return {
    ok: module.status === "connected",
    id,
    message: module.publicSummary,
    checkedAt: now(),
    details: module
  };
}

export async function runModule(id, input = {}) {
  const module = await getModule(id);
  if (!module) {
    return { ok: false, mode: "not_found", reply: `No module registered for ${id}.` };
  }
  const execEnabled = process.env.HERMES_AGENT_OS_ENABLE_EXEC === "1";
  if (module.type === "local_app") {
    await appendModuleLog(id, {
      message: "Local module run requested",
      details: {
        mode: "local_app",
        status: module.status,
        inputKeys: Object.keys(input || {})
      }
    });
    return {
      ok: module.status === "connected",
      mode: "local_app",
      reply: `${module.label} is backed by the local Agent OS store. Open the control room to create and review records.`,
      module
    };
  }
  if (module.type !== "cli" || !execEnabled) {
    await appendModuleLog(id, {
      message: "Module dry run requested",
      details: {
        mode: "dry_run",
        status: module.status,
        execEnabled
      }
    });
    return {
      ok: true,
      mode: "dry_run",
      reply: `${module.label} is ${module.status}. Execution is dry-run until HERMES_AGENT_OS_ENABLE_EXEC=1 is set locally.`,
      module
    };
  }
  const stored = await getStoredConnectionConfig();
  const definition = cliDefinition(id);
  const resolved = definition ? await resolveCliCommand(definition, stored) : { commandPath: await which(id === "claude" ? "claude" : id) };
  const commandPath = resolved.commandPath;
  if (!commandPath) {
    await appendModuleLog(id, {
      level: "error",
      message: "Module execution failed: missing CLI",
      details: { command: id === "claude" ? "claude" : id }
    });
    return {
      ok: false,
      mode: "missing_dependency",
      reply: `${module.label} CLI is not installed or not on PATH.`,
      module
    };
  }
  const message = String(input.message || input.prompt || "").slice(0, 4000);
  const result = await runCommand(commandPath, message ? [message] : [], 15000);
  await appendModuleLog(id, {
    level: result.ok ? "info" : "error",
    message: result.ok ? "Module command executed" : "Module command failed",
    details: {
      mode: "executed",
      code: result.code,
      signal: result.signal,
      inputLength: message.length
    }
  });
  return {
    ok: result.ok,
    mode: "executed",
    reply: result.stdout || result.stderr || "Command completed with no output.",
    module
  };
}

export async function getModuleLogs(id) {
  await ensureRuntimeStore();
  return readModuleLogs(id);
}

export function modulesToLegacySnapshot(status, modules) {
  const integrations = modules.map((module) => ({
    ...module,
    connection: module.publicSummary,
    type: module.type || module.category
  }));
  return {
    generatedAt: status.generatedAt,
    host: status.host,
    mode: status.mode,
    publicUrl: status.publicUrl,
    githubRepo: status.githubRepo,
    integrations,
    directories: [
      { label: "config", path: publicRuntimePath("config"), exists: true },
      { label: "workflows", path: publicRuntimePath("workflows"), exists: true },
      { label: "runs", path: publicRuntimePath("runs"), exists: true }
    ],
    flow: ["Firecrawl Builder", "Module Registry", "Model Routing", "Workflows", "Local Store", "Export Audit"]
  };
}
