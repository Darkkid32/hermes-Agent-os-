import {
  Activity,
  Bot,
  BrainCircuit,
  Cable,
  ChevronRight,
  CircleDot,
  Code2,
  Command,
  Cpu,
  DatabaseZap,
  FileCode2,
  Gauge,
  Gem,
  Globe2,
  KanbanSquare,
  LayoutDashboard,
  Link2,
  Loader2,
  MessageSquare,
  NotebookTabs,
  PlugZap,
  Radio,
  Rocket,
  Search,
  ServerCog,
  Settings,
  ShieldCheck,
  Sparkles,
  TerminalSquare,
  Video,
  Workflow,
  X
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
  configureConnection,
  createSelfModuleItem,
  getBuilderStatus,
  getConnections,
  getHealth,
  getIntegrations,
  getOsAudit,
  getSelfModule,
  installModule,
  sendAgentMessage,
  testIntegration
} from "./api";
import type {
  BuilderStatus,
  ConnectionTemplate,
  Health,
  Integration,
  IntegrationSnapshot,
  OsAudit,
  SelfModuleItem,
  SelfModuleState
} from "./types";

const workspaceItems = [
  { id: "mission", label: "Mission Control", icon: LayoutDashboard },
  { id: "agent-builder", label: "Agent Builder", icon: Workflow }
];
const agentItems = [
  { id: "claude", label: "Claude Code", icon: TerminalSquare },
  { id: "openclaw", label: "OpenClaw", icon: Bot },
  { id: "openclaude", label: "OpenClaude", icon: Sparkles },
  { id: "hermes", label: "Hermes", icon: BrainCircuit },
  { id: "gemini", label: "Gemini", icon: Gem },
  { id: "codex", label: "Codex", icon: Code2 },
  { id: "opencode", label: "OpenCode", icon: FileCode2 },
  { id: "free-claude-code", label: "Free Claude Code", icon: PlugZap }
];
const selfItems = [
  { id: "goals", label: "Goals", icon: CircleDot },
  { id: "seo", label: "SEO", icon: Search },
  { id: "video", label: "Video", icon: Video },
  { id: "notebook", label: "Notebook", icon: NotebookTabs },
  { id: "kanban", label: "Kanban", icon: KanbanSquare },
  { id: "usage-credits", label: "Usage Credits", icon: Gauge }
];

const allNavItems = [...workspaceItems, ...agentItems, ...selfItems];
const localSelfModuleIds = new Set(["goals", "seo", "video", "notebook", "kanban", "usage-credits"]);

const iconMap: Record<string, typeof Activity> = {
  claude: TerminalSquare,
  openclaw: Bot,
  openclaude: Sparkles,
  hermes: BrainCircuit,
  gemini: Gem,
  codex: Code2,
  opencode: FileCode2,
  minimax: Cpu,
  gateway: Radio,
  "free-claude-code": PlugZap,
  "firecrawl-builder": Workflow,
  goals: CircleDot,
  seo: Search,
  video: Video,
  notebook: NotebookTabs,
  kanban: KanbanSquare,
  "usage-credits": Gauge,
  "elizaos-runtime": ServerCog,
  "provider-anthropic": BrainCircuit,
  "provider-openai": Sparkles,
  "provider-gemini": Gem,
  "provider-openrouter": Cable,
  "provider-ollama": Cpu,
  "provider-minimax": Cpu,
  "provider-firecrawl": Globe2,
  "provider-convex": DatabaseZap,
  "provider-clerk": ShieldCheck
};

function statusLabel(status: string) {
  if (status === "ready_to_connect") return "Ready";
  if (status === "ready_to_configure") return "Configure";
  if (status === "missing_dependency") return "Missing";
  return status;
}

function statusClass(status: string) {
  if (status === "connected") return "is-online";
  if (status === "ready_to_connect" || status === "ready_to_configure") return "is-ready";
  return "is-muted";
}

function currentSectionLabel(selected: string) {
  if (selected === "plugins") return "Plugins & Connections";
  return allNavItems.find((item) => item.id === selected)?.label || "Mission Control";
}

function isLocalSelfModuleId(id: string) {
  return localSelfModuleIds.has(id);
}

function useRuntime() {
  const [snapshot, setSnapshot] = useState<IntegrationSnapshot | null>(null);
  const [health, setHealth] = useState<Health | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  async function refresh() {
    try {
      setError(null);
      const [healthData, integrationData] = await Promise.all([getHealth(), getIntegrations()]);
      setHealth(healthData);
      setSnapshot(integrationData);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load backend");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    const timer = window.setInterval(refresh, 20000);
    return () => window.clearInterval(timer);
  }, []);

  return { snapshot, health, error, loading, refresh };
}

function Sidebar({
  selected,
  onSelect
}: {
  selected: string;
  onSelect: (id: string) => void;
}) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">H</div>
        <div>
          <strong>Hermes Agent Hub</strong>
          <span>v1.0 backend wired</span>
        </div>
      </div>

      <NavGroup title="Workspace" items={workspaceItems} selected={selected} onSelect={onSelect} />
      <NavGroup title="Agents" items={agentItems} selected={selected} onSelect={onSelect} />
      <NavGroup title="Self" items={selfItems} selected={selected} onSelect={onSelect} />

      <div className="gateway-pill">
        <Radio size={15} />
        <span>Gateway</span>
        <b>API backed</b>
      </div>
    </aside>
  );
}

function NavGroup({
  title,
  items,
  selected,
  onSelect
}: {
  title: string;
  items: Array<{ id: string; label: string; icon: typeof Activity }>;
  selected: string;
  onSelect: (id: string) => void;
}) {
  return (
    <section className="nav-group">
      <p>{title}</p>
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <button
            className={selected === item.id ? "nav-item active" : "nav-item"}
            key={item.id}
            onClick={() => onSelect(item.id)}
          >
            <Icon size={17} />
            <span>{item.label}</span>
          </button>
        );
      })}
    </section>
  );
}

function TopBar({
  sectionLabel,
  health,
  snapshot,
  loading,
  onRefresh
}: {
  sectionLabel: string;
  health: Health | null;
  snapshot: IntegrationSnapshot | null;
  loading: boolean;
  onRefresh: () => void;
}) {
  return (
    <header className="topbar">
      <div>
        <span>Workspace</span>
        <ChevronRight size={14} />
        <b>{sectionLabel}</b>
      </div>
      <div className="topbar-actions">
        <StatusPill label="MiniMax M3" active={Boolean(snapshot?.integrations.find((i) => i.id === "minimax" && i.status === "connected"))} />
        <StatusPill label="Hermes GW" active={Boolean(snapshot?.integrations.find((i) => i.id === "gateway" && i.status === "connected"))} />
        <StatusPill label={health?.mode || "backend"} active={Boolean(health?.ok)} />
        <button className="icon-button" onClick={onRefresh} aria-label="Refresh runtime">
          {loading ? <Loader2 className="spin" size={17} /> : <Activity size={17} />}
        </button>
      </div>
    </header>
  );
}

function StatusPill({ label, active }: { label: string; active: boolean }) {
  return <span className={active ? "status-pill active" : "status-pill"}>{label}</span>;
}

function MissionControl({
  snapshot,
  error,
  onOpenAgent,
  onOpenPlugins,
  onOpenDrawer
}: {
  snapshot: IntegrationSnapshot | null;
  error: string | null;
  onOpenAgent: (id: string) => void;
  onOpenPlugins: () => void;
  onOpenDrawer: (integration: Integration) => void;
}) {
  const integrations = snapshot?.integrations || [];
  const topCards = integrations.filter((item) =>
    ["claude", "openclaw", "openclaude", "hermes", "firecrawl-builder", "codex", "gateway", "elizaos-runtime"].includes(item.id)
  );
  const providers = integrations.filter((item) => item.category === "provider");
  const selfModules = integrations.filter((item) => item.category === "self");
  const setupItems = buildSetupChecklist(integrations);

  return (
    <main className="content">
      <section className="hero-panel">
        <div className="hero-copy">
          <span className="eyebrow">
            <DatabaseZap size={16} />
            Self-hosted runtime
          </span>
          <h1>Hermes Mission Control</h1>
          <p>Local Agent OS dashboard for connecting CLIs, model providers, workflows, local memory, and usage tracking.</p>
          <div className="runtime-line">
            <b>LOCAL RUNTIME</b>
            <span>{snapshot?.osStatus?.runtimeFoundation || "Agent OS runtime"}</span>
            <span>{snapshot?.osStatus?.builderFoundation || "Firecrawl builder"}</span>
            <span>{snapshot?.osStatus?.moduleCount || integrations.length} modules</span>
          </div>
          {error ? <div className="error-banner">{error}</div> : null}
        </div>
        <div className="hero-actions">
          <button onClick={onOpenPlugins}>
            <Cable size={18} />
            Plugins & Connections
          </button>
          <button className="primary" onClick={() => onOpenAgent("free-claude-code")}>
            <PlugZap size={18} />
            Configure Routing
          </button>
        </div>
      </section>

      <section className="readiness-grid">
        <div className="readiness-panel">
          <span className="eyebrow">
            <ShieldCheck size={16} />
            Setup checklist
          </span>
          <div className="checklist">
            {setupItems.map((item) => (
              <button className="check-row" key={item.id} onClick={() => item.target ? onOpenAgent(item.target) : onOpenPlugins()}>
                <span className={item.done ? "check-dot done" : "check-dot"} />
                <div>
                  <b>{item.label}</b>
                  <small>{item.detail}</small>
                </div>
              </button>
            ))}
          </div>
        </div>
        <div className="readiness-panel">
          <span className="eyebrow">
            <Gauge size={16} />
            Package mode
          </span>
          <div className="package-facts">
            <Metric label="Runtime" value={snapshot?.osStatus?.service || "hermes-agent-os-runtime"} />
            <Metric label="Store" value={snapshot?.osStatus?.store?.root || "~/.hermes-agent-os/"} />
            <Metric label="Connected" value={`${integrations.filter((item) => item.status === "connected").length}/${integrations.length || 0}`} />
            <Metric label="Export" value="clean package audit enabled" />
          </div>
        </div>
      </section>

      <section className="status-grid">
        {topCards.map((item) => (
          <HealthCard integration={item} key={item.id} onOpen={() => onOpenDrawer(item)} />
        ))}
      </section>

      <SectionHeading title="Agents" suffix="click to open control room" />
      <section className="agent-grid">
        {integrations
          .filter((item) => ["claude", "openclaw", "openclaude", "hermes", "gemini", "codex", "opencode", "free-claude-code"].includes(item.id))
          .map((item) => (
            <AgentCard integration={item} key={item.id} onOpen={() => onOpenAgent(item.id)} />
          ))}
      </section>

      <SectionHeading title="Model Providers" suffix="connect your own keys and local endpoints" />
      <section className="agent-grid">
        {providers
          .map((item) => (
            <AgentCard integration={item} key={item.id} onOpen={() => onOpenAgent(item.id)} />
          ))}
      </section>

      <SectionHeading title="Local Workspace" suffix="works without external API keys" />
      <section className="agent-grid">
        {selfModules.map((item) => (
          <AgentCard integration={item} key={item.id} onOpen={() => onOpenAgent(item.id)} />
        ))}
      </section>
    </main>
  );
}

function buildSetupChecklist(integrations: Integration[]) {
  const byId = new Map(integrations.map((item) => [item.id, item]));
  const hasAnyProvider = ["provider-openrouter", "provider-minimax", "provider-openai", "provider-anthropic", "provider-gemini", "provider-ollama"]
    .some((id) => byId.get(id)?.status === "connected");
  const localModulesReady = ["goals", "seo", "video", "notebook", "kanban", "usage-credits"]
    .every((id) => byId.get(id)?.status === "connected");
  return [
    {
      id: "runtime",
      label: "Runtime API",
      detail: byId.get("elizaos-runtime")?.status === "connected" ? "elizaOS core is loadable" : "backend is waiting for runtime dependency",
      done: byId.get("elizaos-runtime")?.status === "connected",
      target: "elizaos-runtime"
    },
    {
      id: "providers",
      label: "Model provider",
      detail: hasAnyProvider ? "at least one model route is configured" : "connect OpenRouter, MiniMax, Ollama, OpenAI, Anthropic, or Gemini",
      done: hasAnyProvider,
      target: "provider-openrouter"
    },
    {
      id: "routing",
      label: "Agent routing",
      detail: byId.get("free-claude-code")?.status === "connected" ? "local/open routing profile configured" : "configure Free Claude Code with OpenRouter, Ollama, or MiniMax",
      done: byId.get("free-claude-code")?.status === "connected",
      target: "free-claude-code"
    },
    {
      id: "builder",
      label: "Open Agent Builder",
      detail: byId.get("firecrawl-builder")?.status === "connected" ? "Firecrawl execution configured" : "add Convex, Clerk, Firecrawl, and LLM keys before builder execution",
      done: byId.get("firecrawl-builder")?.status === "connected",
      target: "firecrawl-builder"
    },
    {
      id: "workspace",
      label: "Local workspace",
      detail: localModulesReady ? "Goals, SEO, Video, Notebook, Kanban, and Credits are ready" : "local self modules are not all ready",
      done: localModulesReady,
      target: "goals"
    }
  ];
}

function HealthCard({ integration, onOpen }: { integration: Integration; onOpen: () => void }) {
  const Icon = iconMap[integration.id] || Activity;
  return (
    <button className="health-card" onClick={onOpen}>
      <div>
        <Icon size={18} />
        <strong>{integration.label}</strong>
      </div>
      <span className={statusClass(String(integration.status))}>{statusLabel(String(integration.status))}</span>
      <dl>
        <dt>{integration.type}</dt>
        <dd>{integration.version || integration.profile || integration.profileCount || integration.connection}</dd>
      </dl>
    </button>
  );
}

function AgentCard({ integration, onOpen }: { integration: Integration; onOpen: () => void }) {
  const Icon = iconMap[integration.id] || Bot;
  return (
    <article className="agent-card">
      <div className="agent-card-head">
        <div className="agent-icon">
          <Icon size={22} />
        </div>
        <div>
          <h3>{integration.label}</h3>
          <p>{integration.connection}</p>
        </div>
        <span className={statusClass(String(integration.status))}>{statusLabel(String(integration.status))}</span>
      </div>
      <div className="metric-row">
        <Metric label="Category" value={integration.category || integration.type} />
        <Metric label="Configured" value={integration.configured ? "yes" : "needs setup"} />
        <Metric label="Missing" value={integration.missing?.length ? integration.missing.join(", ") : "none"} />
      </div>
      <button className="wide-action" onClick={onOpen}>
        Open control room
      </button>
    </article>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="metric">
      <span>{label}</span>
      <b title={value}>{value}</b>
    </div>
  );
}

function SectionHeading({ title, suffix }: { title: string; suffix?: string }) {
  return (
    <div className="section-heading">
      <h2>{title}</h2>
      {suffix ? <span>{suffix}</span> : null}
    </div>
  );
}

function PluginsPage({
  snapshot,
  onOpenDrawer
}: {
  snapshot: IntegrationSnapshot | null;
  onOpenDrawer: (integration: Integration) => void;
}) {
  const integrations = snapshot?.integrations || [];
  const flow = snapshot?.flow || [];
  const [audit, setAudit] = useState<OsAudit | null>(null);
  const [auditError, setAuditError] = useState<string | null>(null);

  useEffect(() => {
    getOsAudit()
      .then((data) => {
        setAudit(data);
        setAuditError(null);
      })
      .catch((err) => {
        setAudit(null);
        setAuditError(err instanceof Error ? err.message : "Unable to load OS audit");
      });
  }, [snapshot?.generatedAt]);

  return (
    <main className="content">
      <section className="hero-panel compact">
        <div className="hero-copy">
          <span className="eyebrow">
            <PlugZap size={16} />
            Plugins & Connections
          </span>
          <h1>Connect every agent lane</h1>
          <p>Local CLIs, Hermes gateway profiles, model providers, browser control, and deployment signals in one connected hub.</p>
        </div>
      </section>

      <section className="flow-panel">
        {flow.map((step, index) => (
          <div className="flow-step" key={`${step}-${index}`}>
            <span>{index + 1}</span>
            <b>{step}</b>
          </div>
        ))}
      </section>

      <ToolAuditPanel audit={audit} error={auditError} integrations={integrations} onOpenDrawer={onOpenDrawer} />

      <section className="plugin-grid">
        {integrations.map((item) => (
          <PluginCard integration={item} key={item.id} onOpen={() => onOpenDrawer(item)} />
        ))}
      </section>
    </main>
  );
}

function ToolAuditPanel({
  audit,
  error,
  integrations,
  onOpenDrawer
}: {
  audit: OsAudit | null;
  error: string | null;
  integrations: Integration[];
  onOpenDrawer: (integration: Integration) => void;
}) {
  const byId = new Map(integrations.map((item) => [item.id, item]));
  const needsWork = audit?.items.filter((item) => item.severity !== "ok").slice(0, 12) || [];
  return (
    <section className="audit-panel">
      <div className="audit-head">
        <span className="eyebrow">
          <ShieldCheck size={16} />
          OS tool audit
        </span>
        {audit ? (
          <div className="audit-summary">
            <Metric label="Ready" value={String(audit.summary.ok)} />
            <Metric label="Setup" value={String(audit.summary.setup)} />
            <Metric label="Action" value={String(audit.summary.actionRequired)} />
          </div>
        ) : null}
      </div>
      {error ? <div className="error-banner">{error}</div> : null}
      <div className="audit-list">
        {needsWork.length ? needsWork.map((item) => {
          const integration = byId.get(item.id);
          return (
            <article className="audit-row" key={item.id}>
              <div>
                <b>{item.label}</b>
                <span className={statusClass(item.status)}>{statusLabel(item.status)}</span>
                <p>{item.fix}</p>
              </div>
              {integration ? (
                <button onClick={() => onOpenDrawer(integration)}>
                  Inspect
                </button>
              ) : null}
            </article>
          );
        }) : (
          <p className="audit-empty">Every registered module is connected or locally ready.</p>
        )}
      </div>
    </section>
  );
}

function AgentBuilderPage() {
  const [status, setStatus] = useState<BuilderStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  async function refreshBuilder() {
    try {
      setError(null);
      setStatus(await getBuilderStatus());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load builder status");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refreshBuilder();
  }, []);

  return (
    <main className="original-builder-page">
      {status?.live ? (
        <section className="original-builder-frame-shell">
          <iframe
            title="Original Agent Builder"
            src={status.proxiedUrl}
            className="original-builder-frame"
          />
        </section>
      ) : (
        <section className="builder-status-panel">
          <span className="eyebrow">
            <Workflow size={16} />
            Real Agent Builder
          </span>
          <h1>Open Agent Builder is reset to upstream source</h1>
          <p>
            Hermes now uses the vendored Firecrawl Open Agent Builder with only an isolated purple theme layer.
            The previous custom lead-intake workflow and mock builder canvas are no longer used here.
          </p>
          {error ? <div className="error-banner">{error}</div> : null}
          <div className="builder-status-grid">
            <Metric label="Status" value={loading ? "checking" : status?.status || "unknown"} />
            <Metric label="Source" value={status?.source || "vendor/open-agent-builder"} />
            <Metric label="Upstream" value={status?.upstreamCommit?.slice(0, 12) || "unverified"} />
            <Metric label="Theme" value={status?.theme || "Hermes purple"} />
          </div>
          <div className="command-stack">
            <label>
              Install dependencies
              <code>{status?.installCommand || "npm run builder:install"}</code>
            </label>
            <label>
              Start real builder
              <code>{status?.startCommand || "npm run builder:start"}</code>
            </label>
          </div>
          <div className="builder-status-actions">
            <button onClick={refreshBuilder}>
              {loading ? <Loader2 className="spin" size={17} /> : <Activity size={17} />}
              Refresh
            </button>
            <a href="/agent-builder-source/?view=builder" target="_blank" rel="noreferrer">
              Open proxied builder
            </a>
          </div>
        </section>
      )}
    </main>
  );
}

function PluginCard({ integration, onOpen }: { integration: Integration; onOpen: () => void }) {
  const Icon = iconMap[integration.id] || Link2;
  return (
    <article className="plugin-card">
      <div className="plugin-title">
        <Icon size={20} />
        <div>
          <strong>{integration.label}</strong>
          <span>{integration.type}</span>
        </div>
        <em className={statusClass(String(integration.status))}>{statusLabel(String(integration.status))}</em>
      </div>
      <p>{integration.connection}</p>
      <div className="plugin-actions">
        <button onClick={onOpen}>Connect</button>
        <button onClick={onOpen}>Test</button>
        <button onClick={onOpen}>Logs</button>
      </div>
    </article>
  );
}

function ControlRoom({
  id,
  snapshot,
  onOpenPlugins
}: {
  id: string;
  snapshot: IntegrationSnapshot | null;
  onOpenPlugins: () => void;
}) {
  const integration = useMemo(() => {
    return snapshot?.integrations.find((item) => item.id === id) || null;
  }, [id, snapshot]);
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [installResult, setInstallResult] = useState<string | null>(null);
  const [template, setTemplate] = useState<ConnectionTemplate | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [saving, setSaving] = useState(false);
  const [installing, setInstalling] = useState(false);

  useEffect(() => {
    getConnections()
      .then((data) => {
        const found = data.templates.find((item) => item.id === id) || null;
        setTemplate(found);
        setFields({});
      })
      .catch(() => {
        setTemplate(null);
        setFields({});
      });
  }, [id]);

  if (!integration) {
    return (
      <main className="content">
        <EmptyPanel title="Connector ready" body="This workspace is wired. Pick another agent or open plugin connections." />
      </main>
    );
  }

  if (isLocalSelfModuleId(integration.id)) {
    return <SelfModuleControl integration={integration} onOpenPlugins={onOpenPlugins} />;
  }

  async function send() {
    if (!message.trim()) return;
    setBusy(true);
    try {
      const result = await sendAgentMessage(integration!.id === "free-claude-code" ? "claude" : integration!.id, message);
      setReply(result.reply);
    } catch (err) {
      setReply(err instanceof Error ? err.message : "Dispatch failed");
    } finally {
      setBusy(false);
    }
  }

  async function saveConfiguration() {
    const cleaned = Object.fromEntries(
      Object.entries(fields).filter(([, value]) => value.trim() !== "")
    );
    if (!Object.keys(cleaned).length) {
      setTestResult("Add at least one value before saving configuration.");
      return;
    }
    setSaving(true);
    setTestResult(null);
    try {
      const result = await configureConnection(integration!.id, cleaned);
      setTestResult(`Saved local configuration fields: ${result.configuredFields.join(", ")}`);
      setFields({});
    } catch (err) {
      setTestResult(err instanceof Error ? err.message : "Configuration save failed");
    } finally {
      setSaving(false);
    }
  }

  async function runTest() {
    setBusy(true);
    setTestResult(null);
    try {
      const data = await testIntegration(integration!.id);
      setTestResult(data.message);
    } catch (err) {
      setTestResult(err instanceof Error ? err.message : "Test failed");
    } finally {
      setBusy(false);
    }
  }

  async function prepareModuleInstall() {
    setInstalling(true);
    setInstallResult(null);
    try {
      const result = await installModule(integration!.id, false);
      setInstallResult(result.message);
    } catch (err) {
      setInstallResult(err instanceof Error ? err.message : "Install preparation failed");
    } finally {
      setInstalling(false);
    }
  }

  return (
    <main className="content two-column">
      <section className="control-room">
        <div className="control-header">
          <span className="eyebrow">
            <Command size={16} />
            Control room
          </span>
          <h1>{integration.label}</h1>
          <p>{integration.connection}</p>
        </div>

        <section className="setup-panel">
          <div className="setup-row">
            <b>Install</b>
            <p>{integration.installHint || "Install the local tool or configure a path/API key below."}</p>
            {integration.installCommand ? <code>{integration.installCommand}</code> : null}
            {integration.docsUrl ? (
              <a href={integration.docsUrl} target="_blank" rel="noreferrer">Open docs</a>
            ) : null}
            {integration.actions?.includes("install") || integration.installCommand ? (
              <button className="wide-action" onClick={prepareModuleInstall} disabled={installing}>
                {installing ? <Loader2 className="spin" size={18} /> : <Rocket size={18} />}
                Prepare install
              </button>
            ) : null}
            {installResult ? <div className="test-result">{installResult}</div> : null}
          </div>

          <div className="setup-row">
            <b>Connect</b>
            <p>{template?.notes || "Save local configuration for this module. Secret values are redacted by the backend."}</p>
            <div className="config-grid">
              {(template?.fields || integration.configKeys || []).map((field) => (
                <label key={field}>
                  <span>{field}</span>
                  <input
                    value={fields[field] || ""}
                    onChange={(event) => setFields((current) => ({ ...current, [field]: event.target.value }))}
                    placeholder={template?.configuredFields?.includes(field) ? "configured" : "paste value or local path"}
                    type={field.includes("KEY") || field.includes("TOKEN") ? "password" : "text"}
                  />
                </label>
              ))}
            </div>
            <button className="wide-action" onClick={saveConfiguration} disabled={saving}>
              {saving ? <Loader2 className="spin" size={18} /> : <Settings size={18} />}
              Save local config
            </button>
          </div>
        </section>

        <div className="composer">
          <input value={message} onChange={(event) => setMessage(event.target.value)} placeholder={`Message ${integration.label}...`} />
          <button onClick={send} disabled={busy || !message.trim()}>
            {busy ? <Loader2 className="spin" size={18} /> : <MessageSquare size={18} />}
            Dry run
          </button>
        </div>
        {reply ? (
          <div className="test-result">
            <b>Run result</b>
            <p>{reply}</p>
          </div>
        ) : null}
      </section>

      <aside className="side-panel">
        <h3>Connector status</h3>
        <Metric label="Status" value={statusLabel(String(integration.status))} />
        <Metric label="Category" value={integration.category || integration.type} />
        <Metric label="Configured" value={integration.configured ? "yes" : "needs setup"} />
        <Metric label="Capabilities" value={integration.capabilities?.join(", ") || "registered"} />
        <Metric label="Config fields" value={(template?.configuredFields?.length ? template.configuredFields : integration.configKeys || []).join(", ") || "none"} />
        <button className="wide-action" onClick={runTest} disabled={busy}>
          {busy ? <Loader2 className="spin" size={18} /> : <Gauge size={18} />}
          Test connection
        </button>
        {testResult ? <div className="test-result">{testResult}</div> : null}
        <button className="wide-action" onClick={onOpenPlugins}>
          Open plugin matrix
        </button>
      </aside>
    </main>
  );
}

function defaultSelfForm(id: string): Record<string, string> {
  if (id === "usage-credits") return { title: "", provider: "", units: "", estimatedCost: "" };
  if (id === "kanban") return { title: "", column: "todo", notes: "" };
  if (id === "notebook") return { title: "", body: "" };
  if (id === "seo") return { title: "", url: "", keyword: "", status: "planned", notes: "" };
  if (id === "video") return { title: "", sourcePath: "", workflow: "captioning", status: "queued", notes: "" };
  return { title: "", status: "open", notes: "" };
}

function itemDetail(item: SelfModuleItem) {
  const parts = [
    item.status,
    item.column,
    item.provider,
    item.keyword,
    item.workflow,
    item.url,
    item.sourcePath,
    item.units != null ? `${item.units} units` : "",
    item.estimatedCost != null ? `$${Number(item.estimatedCost).toFixed(4)}` : ""
  ].filter(Boolean);
  return parts.join(" / ") || "local item";
}

function SelfModuleControl({
  integration,
  onOpenPlugins
}: {
  integration: Integration;
  onOpenPlugins: () => void;
}) {
  const [state, setState] = useState<SelfModuleState | null>(null);
  const [form, setForm] = useState<Record<string, string>>(() => defaultSelfForm(integration.id));
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  useEffect(() => {
    setState(null);
    setForm(defaultSelfForm(integration.id));
    setResult(null);
    getSelfModule(integration.id)
      .then(setState)
      .catch((err) => setResult(err instanceof Error ? err.message : "Unable to load local module"));
  }, [integration.id]);

  function updateField(field: string, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function createItem() {
    setBusy(true);
    setResult(null);
    try {
      const payload: Record<string, string | number> = { ...form };
      if (integration.id === "usage-credits") {
        payload.units = Number(form.units || 0);
        payload.estimatedCost = Number(form.estimatedCost || 0);
      }
      const next = await createSelfModuleItem(integration.id, payload);
      setState(next);
      setForm(defaultSelfForm(integration.id));
      setResult(`Saved ${next.itemName}.`);
    } catch (err) {
      setResult(err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="content two-column">
      <section className="control-room">
        <div className="control-header">
          <span className="eyebrow">
            <Command size={16} />
            Local module
          </span>
          <h1>{integration.label}</h1>
          <p>{integration.publicSummary}</p>
        </div>

        <section className="setup-panel">
          <div className="setup-row">
            <b>Create {state?.itemName || "item"}</b>
            <div className="config-grid">
              <label>
                <span>Title</span>
                <input
                  value={form.title || ""}
                  onChange={(event) => updateField("title", event.target.value)}
                  placeholder={`${integration.label} title`}
                />
              </label>
              {integration.id === "goals" ? (
                <label>
                  <span>Status</span>
                  <input value={form.status || ""} onChange={(event) => updateField("status", event.target.value)} />
                </label>
              ) : null}
              {integration.id === "kanban" ? (
                <label>
                  <span>Column</span>
                  <input value={form.column || ""} onChange={(event) => updateField("column", event.target.value)} />
                </label>
              ) : null}
              {integration.id === "seo" ? (
                <>
                  <label>
                    <span>URL</span>
                    <input value={form.url || ""} onChange={(event) => updateField("url", event.target.value)} placeholder="https://example.com" />
                  </label>
                  <label>
                    <span>Keyword</span>
                    <input value={form.keyword || ""} onChange={(event) => updateField("keyword", event.target.value)} placeholder="target keyword" />
                  </label>
                  <label>
                    <span>Status</span>
                    <input value={form.status || ""} onChange={(event) => updateField("status", event.target.value)} />
                  </label>
                </>
              ) : null}
              {integration.id === "video" ? (
                <>
                  <label>
                    <span>Source path</span>
                    <input value={form.sourcePath || ""} onChange={(event) => updateField("sourcePath", event.target.value)} placeholder="/path/to/video.mp4" />
                  </label>
                  <label>
                    <span>Workflow</span>
                    <input value={form.workflow || ""} onChange={(event) => updateField("workflow", event.target.value)} />
                  </label>
                  <label>
                    <span>Status</span>
                    <input value={form.status || ""} onChange={(event) => updateField("status", event.target.value)} />
                  </label>
                </>
              ) : null}
              {integration.id === "usage-credits" ? (
                <>
                  <label>
                    <span>Provider</span>
                    <input value={form.provider || ""} onChange={(event) => updateField("provider", event.target.value)} placeholder="openai" />
                  </label>
                  <label>
                    <span>Units</span>
                    <input value={form.units || ""} onChange={(event) => updateField("units", event.target.value)} inputMode="decimal" />
                  </label>
                  <label>
                    <span>Estimated cost</span>
                    <input value={form.estimatedCost || ""} onChange={(event) => updateField("estimatedCost", event.target.value)} inputMode="decimal" />
                  </label>
                </>
              ) : null}
              {integration.id !== "usage-credits" ? (
                <label className="is-wide">
                  <span>{integration.id === "notebook" ? "Body" : "Notes"}</span>
                  <textarea
                    value={form.body || form.notes || ""}
                    onChange={(event) => updateField(integration.id === "notebook" ? "body" : "notes", event.target.value)}
                    placeholder="Local private text"
                  />
                </label>
              ) : null}
            </div>
            <button className="wide-action" onClick={createItem} disabled={busy}>
              {busy ? <Loader2 className="spin" size={18} /> : <Settings size={18} />}
              Save local {state?.itemName || "item"}
            </button>
            {result ? <div className="test-result">{result}</div> : null}
          </div>

          <div className="setup-row">
            <b>Local records</b>
            <div className="local-list">
              {state?.items.length ? (
                state.items.slice(0, 12).map((item) => (
                  <article key={item.id} className="local-item">
                    <strong>{item.title}</strong>
                    <span>{itemDetail(item)}</span>
                    {item.body || item.notes ? <p>{item.body || item.notes}</p> : null}
                  </article>
                ))
              ) : (
                <p>No local records yet.</p>
              )}
            </div>
          </div>
        </section>
      </section>

      <aside className="side-panel">
        <h3>Local status</h3>
        <Metric label="Status" value={statusLabel(String(integration.status))} />
        <Metric label="Items" value={String(state?.summary.total ?? 0)} />
        <Metric label="Updated" value={state?.updatedAt ? new Date(state.updatedAt).toLocaleString() : "not yet"} />
        {integration.id === "usage-credits" ? (
          <>
            <Metric label="Units" value={String(state?.summary.usage.units ?? 0)} />
            <Metric label="Estimated spend" value={`$${Number(state?.summary.usage.estimatedCost || 0).toFixed(4)}`} />
          </>
        ) : null}
        <Metric label="Capabilities" value={integration.capabilities?.join(", ") || "local app"} />
        <button className="wide-action" onClick={onOpenPlugins}>
          Open plugin matrix
        </button>
      </aside>
    </main>
  );
}

function EmptyPanel({ title, body }: { title: string; body: string }) {
  return (
    <section className="hero-panel">
      <div className="hero-copy">
        <h1>{title}</h1>
        <p>{body}</p>
      </div>
    </section>
  );
}

function Drawer({
  integration,
  onClose
}: {
  integration: Integration | null;
  onClose: () => void;
}) {
  const [result, setResult] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!integration) return null;

  async function runTest() {
    setBusy(true);
    setResult(null);
    try {
      const data = await testIntegration(integration!.id);
      setResult(data.message);
    } catch (err) {
      setResult(err instanceof Error ? err.message : "Test failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="drawer-backdrop" onClick={onClose}>
      <aside className="drawer" onClick={(event) => event.stopPropagation()}>
        <button className="drawer-close" onClick={onClose} aria-label="Close">
          <X size={18} />
        </button>
        <span className="eyebrow">
          <ShieldCheck size={16} />
          Connection detail
        </span>
        <h2>{integration.label}</h2>
        <p>{integration.connection}</p>
        <div className="drawer-stack">
          <Metric label="Status" value={statusLabel(String(integration.status))} />
          <Metric label="Category" value={integration.category || integration.type} />
          <Metric label="Configured" value={integration.configured ? "yes" : "needs setup"} />
          <Metric label="Missing" value={integration.missing?.length ? integration.missing.join(", ") : "none"} />
        </div>
        <button className="wide-action" onClick={runTest} disabled={busy}>
          {busy ? <Loader2 className="spin" size={18} /> : <Gauge size={18} />}
          Test connection
        </button>
        {result ? <div className="test-result">{result}</div> : null}
      </aside>
    </div>
  );
}

export default function App() {
  const { snapshot, health, error, loading, refresh } = useRuntime();
  const [selected, setSelected] = useState("mission");
  const [drawer, setDrawer] = useState<Integration | null>(null);
  const sectionLabel = currentSectionLabel(selected);
  const selectedModule = Boolean(snapshot?.integrations.some((item) => item.id === selected));

  return (
    <div className="app-shell">
      <Sidebar selected={selected} onSelect={setSelected} />
      <section className="workspace">
        <TopBar sectionLabel={sectionLabel} health={health} snapshot={snapshot} loading={loading} onRefresh={refresh} />
        {selected === "mission" ? (
          <MissionControl
            snapshot={snapshot}
            error={error}
            onOpenAgent={setSelected}
            onOpenPlugins={() => setSelected("plugins")}
            onOpenDrawer={setDrawer}
          />
        ) : selected === "plugins" ? (
          <PluginsPage snapshot={snapshot} onOpenDrawer={setDrawer} />
        ) : selected === "agent-builder" ? (
          <AgentBuilderPage />
        ) : selectedModule || agentItems.some((item) => item.id === selected) || selfItems.some((item) => item.id === selected) ? (
          <ControlRoom id={selected} snapshot={snapshot} onOpenPlugins={() => setSelected("plugins")} />
        ) : (
          <main className="content">
            <EmptyPanel title="Workspace module wired" body={`${selected} is part of the hub shell and ready for the next workflow panel.`} />
          </main>
        )}
      </section>
      <Drawer integration={drawer} onClose={() => setDrawer(null)} />
    </div>
  );
}
